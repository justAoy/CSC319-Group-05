package mountain_path;

import java.util.*;
import java.io.*;
import java.awt.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.Collections;

public class MapDataDrawer {

    private int[][] grid;

    public MapDataDrawer(String filename, int rows, int cols) throws IOException {
        grid = new int[rows][cols];
        scanIn(filename, grid);
        // initialize grid 
        //read the data from the file into the grid
    }

    public void scanIn(String filename, int[][] grid) throws FileNotFoundException, IOException {
        try (Scanner read = new Scanner(new File(filename))) {
            int i = 0, j = 0;
            while (i != grid.length) {
                grid[i][j++] = Integer.parseInt(read.next());
                if (j == grid[0].length) {
                    i++;
                    j = 0;
                }
            }
//      for(int x = 0 ; x < grid.length ; x++){
//          for(int y = 0 ; y < grid[0].length ; y++){
//              System.out.print(grid[x][y]+" ");
//          }
//          System.out.println();
//      }
            System.out.println("length " + grid.length);
            System.out.println("[0]length " + grid[0].length);
//     System.out.println(grid[479][843]);
        }
        /**
         * @return the min value in the entire grid
         */
    }

    public int findMinValue() {
        int min = grid[0][0];
        for (int x = 0; x < grid.length; x++) {
            for (int y = 0; y < grid[0].length; y++) {
                if (grid[x][y] < min) {
                    min = grid[x][y];
                }
            }
        }
        return min;
        /**
         * @return the max value in the entire grid
         */
    }

    public int findMaxValue() {
        int max = grid[0][0];
        for (int x = 0; x < grid.length; x++) {
            for (int y = 0; y < grid[0].length; y++) {
                if (grid[x][y] > max) {
                    max = grid[x][y];
                }
            }
        }
        return max;

    }

    public int indexOfMinInCol(int col) {
        int min = grid[0][col];
        int num = 0;
        for (int i = 0; i < grid.length; i++) {
            if (grid[i][col] < min) {
                min = grid[i][col];
                num = i;
            }
        }

        return num;
        /**
         * @param col the column of the grid to check
         * @return the index of the row with the lowest value in the given col
         * for the grid
         */
    }

    /**
     * Draws the grid using the given Graphics object. Colors should be
     * grayscale values 0-255, scaled based on min/max values in grid
     */
    public void drawMap(Graphics g) {
        int min = findMinValue();
        int max = findMaxValue();
        for (int x = 0; x < grid[0].length; x++) {
            for (int y = 0; y < grid.length; y++) {
                int c = (grid[y][x] - min) / ((max - min) / 255);
                g.setColor(new Color(c, c, c));
                g.fillRect(x, y, 1, 1);
            }
        }

    }

    public int greedyWalk(int number, int top, int mid, int down) {
        int result = 0;
        int top1 = Math.abs(number - top);
        int mid1 = Math.abs(number - mid);
        int down1 = Math.abs(number - down);
        int min;
        min = Math.min(Math.min(top1, mid1), down1);
        if (min == mid1) {
            result = mid;
        } else if (min == top1 && min != down1) {// top
            result = top;
        } else if (min == down1 && min != top1) {//down    
            result = down;
        } else if (min == top1 && min == down1) {
            int x = (int) (Math.random() * 100);
            if (x < 50) {
                result = top;
            } else {
                result = down;
            }
        }
        return result;

    }

    /**
     * Find a path from West-to-East starting at given row. Choose a foward step
     * out of 3 possible forward locations, using greedy method described in
     * assignment.
     *
     * @return the total change in elevation traveled from West-to-East
     */
    public int drawLowestElevPath(Graphics g, int row) {
        int mid, top, down;// mid = row , top = row-1,dowm = row+1
        g.fillRect(0, row, 1, 1);
        int num = grid[row][0];
        int minNumber;
        int change = 0;
        for (int y = 1; y < grid[0].length; y++) {
            if(row == 0) {
                mid = grid[row][y];
                down = grid[row + 1][y];
                top = 999999;
            } else if (row == grid.length - 1) { // >479
                mid = grid[row][y];
                top = grid[row - 1][y];
                down = 999999;
            } else{
                mid = grid[row][y];
                top = grid[row - 1][y];
                down = grid[row + 1][y];
            }
            minNumber = greedyWalk(num, top, mid, down);
            change += Math.abs(num-minNumber);
            if(top == minNumber) {
                row = row - 1;
            }else if (down == minNumber) {
                row = row + 1;
            }
            num = grid[row][y];
            g.fillRect(y, row, 1, 1);

        }

        return change;
    }

    /**
     * @return the index of the starting row for the lowest-elevation-change
     * path in the entire grid.
     */
    public int indexOfLowestElevPath(Graphics g) {
        int bestRow = 999999;
        int change;
        int po = 0;
        for (int x = 0; x < grid.length; x++) { // 480
            change = drawLowestElevPath(g, x);
            if (change < bestRow) {
                bestRow = change;
                po = x;
            }
        }
        return po;
    }
}
